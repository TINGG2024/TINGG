// 用户配置文件类型
export interface Profile {
  id: string;
  username?: string;
  email?: string;
  avatar_url?: string;
  created_at?: string;
  updated_at?: string;
}
