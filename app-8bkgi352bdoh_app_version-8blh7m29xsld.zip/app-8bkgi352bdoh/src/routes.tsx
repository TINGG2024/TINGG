import ResumePage from './pages/ResumePage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: '李宇婷个人简历',
    path: '/',
    element: <ResumePage />
  }
];

export default routes;
