import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mail, Phone, MapPin, Menu, X, GraduationCap, Heart } from 'lucide-react';

export default function ResumePage() {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // 监听滚动进度
  useEffect(() => {
    const handleScroll = () => {
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;
      const scrollTop = window.scrollY;
      const progress = (scrollTop / (documentHeight - windowHeight)) * 100;
      setScrollProgress(progress);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // 平滑滚动到指定section
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };



  return (
    <div className="min-h-screen">
      {/* 顶部导航栏 */}
      <nav className="fixed top-0 left-0 right-0 z-50 premium-nav">
        <div className="max-w-6xl mx-auto px-4 xl:px-8">
          <div className="flex items-center justify-between h-16">
            <h1 className="text-xl font-bold text-foreground">李宇婷</h1>
            
            {/* 桌面导航 */}
            <div className="hidden xl:flex items-center gap-6">
              <button
                type="button"
                onClick={() => scrollToSection('about')}
                className="text-sm text-foreground hover:text-primary transition-colors"
              >
                关于我
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('education')}
                className="text-sm text-foreground hover:text-primary transition-colors"
              >
                教育经历
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('interests')}
                className="text-sm text-foreground hover:text-primary transition-colors"
              >
                兴趣爱好
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('contact')}
                className="text-sm text-foreground hover:text-primary transition-colors"
              >
                联系方式
              </button>
            </div>

            {/* 移动端菜单按钮 */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* 移动端菜单 */}
          {mobileMenuOpen && (
            <div className="xl:hidden py-4 border-t border-border">
              <div className="flex flex-col gap-4">
                <button
                  type="button"
                  onClick={() => scrollToSection('about')}
                  className="text-left text-sm text-foreground hover:text-primary transition-colors"
                >
                  关于我
                </button>
                <button
                  type="button"
                  onClick={() => scrollToSection('education')}
                  className="text-left text-sm text-foreground hover:text-primary transition-colors"
                >
                  教育经历
                </button>
                <button
                  type="button"
                  onClick={() => scrollToSection('interests')}
                  className="text-left text-sm text-foreground hover:text-primary transition-colors"
                >
                  兴趣爱好
                </button>
                <button
                  type="button"
                  onClick={() => scrollToSection('contact')}
                  className="text-left text-sm text-foreground hover:text-primary transition-colors"
                >
                  联系方式
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* 滚动进度条 */}
      <div className="fixed bottom-0 left-0 right-0 h-1 bg-secondary z-50">
        <div
          className="h-full bg-primary transition-all duration-150"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* 主要内容 */}
      <main className="pt-16">
        {/* 英雄头部区域 */}
        <section className="py-16 xl:py-24 premium-section-bg">
          <div className="max-w-6xl mx-auto px-4 xl:px-8">
            <div className="text-center">
              <div className="w-24 h-24 xl:w-32 xl:h-32 rounded-full mx-auto mb-6 overflow-hidden border-4 border-primary premium-avatar">
                <img 
                  src="/images/avatar.jpg" 
                  alt="李宇婷" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h1 className="text-3xl xl:text-5xl font-bold text-foreground mb-4">李宇婷</h1>
              <div className="flex flex-wrap justify-center gap-4 xl:gap-6 text-sm xl:text-base text-muted-foreground mb-4">
                <span>女</span>
                <span>•</span>
                <span>本科</span>
                <span>•</span>
                <span>安徽合肥</span>
              </div>
              <p className="text-sm xl:text-base text-muted-foreground mb-8 italic">
                "BEAUTY WITHOUT PASSION IS UNATTRACTIVE"
              </p>
              <div className="flex justify-center">
                <Button onClick={() => scrollToSection('contact')} size="lg">
                  <Mail className="w-4 h-4 mr-2" />
                  联系我
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* 关于我 */}
        <section id="about" className="py-16 xl:py-20">
          <div className="max-w-4xl mx-auto px-4 xl:px-8">
            <div className="flex items-center gap-3 mb-8">
              <span className="text-2xl">👤</span>
              <h2 className="text-2xl xl:text-3xl font-bold text-foreground">关于我</h2>
            </div>
            <Card className="premium-card">
              <CardContent className="p-6 xl:p-8">
                <p className="text-base xl:text-lg text-foreground leading-relaxed mb-4">
                  您好！我是李宇婷，来自安徽合肥，目前在武汉理工大学学习经济专业。我是一名专注的终身学习者，对经济学有着浓厚的兴趣，致力于成为一名优秀的经济学实践者。
                </p>
                <p className="text-base xl:text-lg text-foreground leading-relaxed">
                  除了学术追求外，多样化的兴趣爱好丰富了我的生活，也培养了我的创造力和团队协作能力。我相信知识的变革力量，致力于在个人和职业生涯中不断成长和学习。
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* 教育经历 */}
        <section id="education" className="py-16 xl:py-20 premium-section-bg">
          <div className="max-w-4xl mx-auto px-4 xl:px-8">
            <div className="flex items-center gap-3 mb-8">
              <GraduationCap className="w-6 h-6 text-primary" />
              <h2 className="text-2xl xl:text-3xl font-bold text-foreground">教育经历</h2>
            </div>
            
            {/* 时间线 */}
            <div className="relative">
              {/* 时间线竖线 */}
              <div className="absolute left-4 xl:left-8 top-0 bottom-0 w-0.5 bg-border" />
              
              {/* 教育经历项目 */}
              <div className="space-y-8">
                {/* 武汉理工大学 */}
                <div className="relative pl-12 xl:pl-20">
                  <div className="absolute left-2.5 xl:left-6.5 top-1.5 w-3 h-3 rounded-full bg-primary border-4 border-background" />
                  <Card className="premium-card">
                    <CardContent className="p-6">
                      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between mb-2">
                        <h3 className="text-lg xl:text-xl font-semibold text-foreground">武汉理工大学</h3>
                        <span className="text-sm text-muted-foreground mt-1 xl:mt-0">2024.9 - 至今</span>
                      </div>
                      <p className="text-base text-muted-foreground mb-2">攻读经济学士学位</p>
                      <p className="text-sm text-foreground">
                        积极参与社团活动和学术讲座，对经济学有着浓厚的兴趣，致力于成为一名优秀的经济学实践者。
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* 合肥第十中学 */}
                <div className="relative pl-12 xl:pl-20">
                  <div className="absolute left-2.5 xl:left-6.5 top-1.5 w-3 h-3 rounded-full bg-primary border-4 border-background" />
                  <Card className="premium-card">
                    <CardContent className="p-6">
                      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between mb-2">
                        <h3 className="text-lg xl:text-xl font-semibold text-foreground">合肥第十中学</h3>
                        <span className="text-sm text-muted-foreground mt-1 xl:mt-0">2021.9 - 2024.6</span>
                      </div>
                      <p className="text-base text-muted-foreground mb-2">高中文科实验班</p>
                      <p className="text-sm text-foreground">
                        在高中阶段打下了坚实的学科基础，培养了良好的学习习惯和自律能力。
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* 第四十六中学南校区 */}
                <div className="relative pl-12 xl:pl-20">
                  <div className="absolute left-2.5 xl:left-6.5 top-1.5 w-3 h-3 rounded-full bg-muted-foreground border-4 border-background" />
                  <Card className="premium-card">
                    <CardContent className="p-6">
                      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between mb-2">
                        <h3 className="text-lg xl:text-xl font-semibold text-foreground">第四十六中学南校区</h3>
                        <span className="text-sm text-muted-foreground mt-1 xl:mt-0">2018.9 - 2021.6</span>
                      </div>
                      <p className="text-base text-muted-foreground mb-2">初中</p>
                      <p className="text-sm text-foreground">
                        获得"三好学生"称号，担任班干部，培养了团队协作和领导能力。
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* 师范附小四小 */}
                <div className="relative pl-12 xl:pl-20">
                  <div className="absolute left-2.5 xl:left-6.5 top-1.5 w-3 h-3 rounded-full bg-muted-foreground border-4 border-background" />
                  <Card className="premium-card">
                    <CardContent className="p-6">
                      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between mb-2">
                        <h3 className="text-lg xl:text-xl font-semibold text-foreground">师范附小四小</h3>
                        <span className="text-sm text-muted-foreground mt-1 xl:mt-0">2016.9 - 2018.6</span>
                      </div>
                      <p className="text-base text-muted-foreground mb-2">小学高年级</p>
                      <p className="text-sm text-foreground">
                        小学高年级阶段，培养了良好的学习基础和兴趣爱好。
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* 阿奎利亚小学 */}
                <div className="relative pl-12 xl:pl-20">
                  <div className="absolute left-2.5 xl:left-6.5 top-1.5 w-3 h-3 rounded-full bg-muted-foreground border-4 border-background" />
                  <Card className="premium-card">
                    <CardContent className="p-6">
                      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between mb-2">
                        <h3 className="text-lg xl:text-xl font-semibold text-foreground">阿奎利亚小学</h3>
                        <span className="text-sm text-muted-foreground mt-1 xl:mt-0">2012.9 - 2016.6</span>
                      </div>
                      <p className="text-base text-muted-foreground mb-2">小学低年级</p>
                      <p className="text-sm text-foreground">
                        小学低年级阶段，开启了学习生涯的第一步。
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 兴趣爱好 */}
        <section id="interests" className="py-16 xl:py-20">
          <div className="max-w-4xl mx-auto px-4 xl:px-8">
            <div className="flex items-center gap-3 mb-8">
              <Heart className="w-6 h-6 text-primary" />
              <h2 className="text-2xl xl:text-3xl font-bold text-foreground">兴趣爱好</h2>
            </div>
            
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              {/* 养猫 */}
              <Card className="premium-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-3">🐱 养猫</h3>
                  <p className="text-sm text-muted-foreground">
                    喜欢与猫咪相处，享受它们带来的温暖和陪伴，培养了耐心和责任感。
                  </p>
                </CardContent>
              </Card>

              {/* 音乐欣赏 */}
              <Card className="premium-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-3">🎵 音乐欣赏</h3>
                  <p className="text-sm text-muted-foreground">
                    欣赏各种类型的音乐，音乐能够放松心情，激发创造力和灵感。
                  </p>
                </CardContent>
              </Card>

              {/* 动漫 */}
              <Card className="premium-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-3">🎬 动漫</h3>
                  <p className="text-sm text-muted-foreground">
                    热爱动漫文化，通过动漫作品体验不同的故事和情感，丰富精神世界。
                  </p>
                </CardContent>
              </Card>

              {/* 跑步 */}
              <Card className="premium-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-3">🏃 跑步</h3>
                  <p className="text-sm text-muted-foreground">
                    热爱跑步运动，保持健康的身体和积极的心态，享受运动带来的快乐。
                  </p>
                </CardContent>
              </Card>

              {/* 摄影 */}
              <Card className="premium-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-3">📷 摄影</h3>
                  <p className="text-sm text-muted-foreground">
                    喜欢用镜头记录生活中的美好瞬间，培养了观察力和审美能力。
                  </p>
                </CardContent>
              </Card>

              {/* 理财 */}
              <Card className="premium-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-3">💰 理财</h3>
                  <p className="text-sm text-muted-foreground">
                    关注理财知识，学习投资理念，培养财务管理能力和经济思维。
                  </p>
                </CardContent>
              </Card>

              {/* 手工编织 */}
              <Card className="premium-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-3">🧶 手工编织</h3>
                  <p className="text-sm text-muted-foreground">
                    享受手工编织的过程，锻炼动手能力和创造力，体验制作的乐趣。
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* 联系方式 */}
        <section id="contact" className="py-16 xl:py-20 premium-section-bg">
          <div className="max-w-4xl mx-auto px-4 xl:px-8">
            <div className="flex items-center gap-3 mb-8">
              <Mail className="w-6 h-6 text-primary" />
              <h2 className="text-2xl xl:text-3xl font-bold text-foreground">联系方式</h2>
            </div>
            
            <Card className="premium-card">
              <CardContent className="p-6 xl:p-8">
                <div className="space-y-6">
                  {/* 邮箱 */}
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Mail className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-foreground mb-1">邮箱</h3>
                      <p className="text-sm text-muted-foreground">1130715208@qq.com</p>
                    </div>
                  </div>

                  {/* 电话 */}
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Phone className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-foreground mb-1">电话</h3>
                      <p className="text-sm text-muted-foreground">18905605238</p>
                    </div>
                  </div>

                  {/* 微信 */}
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="text-lg">💬</span>
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-foreground mb-1">微信</h3>
                      <p className="text-sm text-muted-foreground">LYT06-2-7</p>
                    </div>
                  </div>

                  {/* QQ */}
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="text-lg">💬</span>
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-foreground mb-1">QQ</h3>
                      <p className="text-sm text-muted-foreground">1130715208</p>
                    </div>
                  </div>

                  {/* 地址 */}
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <MapPin className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-foreground mb-1">地址</h3>
                      <p className="text-sm text-muted-foreground">湖北省武汉市洪山区</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* 页脚 */}
        <footer className="py-8 border-t border-border">
          <div className="max-w-6xl mx-auto px-4 xl:px-8 text-center">
            <p className="text-sm text-muted-foreground">
              © 2025 李宇婷个人简历. 保留所有权利.
            </p>
          </div>
        </footer>
      </main>
    </div>
  );
}
